<?php

if (isset($_SESSION['DRIVER_LOGIN_OTP'])) {
  echo "<script>window.location.href = SITEURL+'/driver/home/'; </script>";
  exit;
}

?>

<script type="text/javascript" src="<?php echo $TPL->modUrl; ?>/js/x-driver.inc.js"></script>
<?php

// $arrFrom = array(
//   array("type" => "text", "name" => "loginOtp", "title" => "loginOtp", "validate" => "required", "attrp" => ' class="c2"'),
//   array("type" => "hidden", "name" => "xAction", "value" => "doctorLogin"),
// );

$arrFrom = array(
  array("type" => "text", "name" => "loginOtp1", "attr" => 'minLength="1" maxLength="1" class="pin"'),
  array("type" => "text", "name" => "loginOtp2", "attr" => 'minLength="1" maxLength="1" class="pin"'),
  array("type" => "text", "name" => "loginOtp3", "attr" => 'minLength="1" maxLength="1" class="pin"'),
  array("type" => "text", "name" => "loginOtp4", "attr" => 'minLength="1" maxLength="1" class="pin"'),
  array("type" => "hidden", "name" => "xAction", "value" => "driverLogin"),
);


$MXFRM = new mxForm();
?>

<div class="mobile-view">
  <div class="login-page">
    <div class="container">
      <div class="login-logo">
        <img src="<?php echo SITEURL ?>/images/logo.png" alt="">
        <h4>Driver Attendance System</h4>
    </div>
      <div class="img-box">
        <img src="<?php echo SITEURL ?>/images/car.png">
        
      </div>
     
      <h3>Enter Pin</h3>
      <form class="wrap-data" name="frmLogin" id="frmLogin" action="" auto="false" method="post" enctype="multipart/form-data">
        <div class="wrap-form f70">
          <ul class="tbl-form">
            <?php echo $MXFRM->getForm($arrFrom); ?>
          </ul>
        </div>
        <a href="javascript:void(0);" class="btn1 fa-save" rel="frmLogin"><span>LOGIN</span></a>
      </form>
    </div>
  </div>
</div>


<script type="text/javascript">
  $(document).ready(function() {
    $('input#loginOtp1').focus();
    $('input#loginOtp1,input#loginOtp2,input#loginOtp3,input#loginOtp4').keyup(function() {
      return isOneDigitNumber(event);
    });

    $(".pin").keyup(function() {
      if (this.value.length == this.maxLength) {
        $(this).closest('li').next('li').find('.pin').focus();
      } else if (this.value.length == 0) {
        $(this).closest('li').prev('li').find('.pin').focus();
      }

      var count = 0;
      $(".pin").each(function() {
        var element = $(this);
        if (element.val() != "") {
          count++;
        }
      });

      if (count == 4) {
        $(".e").html("");
      }

    });


  });
</script>